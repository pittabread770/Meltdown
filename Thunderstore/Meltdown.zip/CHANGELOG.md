## 0.1.1
- Removed in-dev shenanigans

## 0.1.0

- First release
- Hooray!